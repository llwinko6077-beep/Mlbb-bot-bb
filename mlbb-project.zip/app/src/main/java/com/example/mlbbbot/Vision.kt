package com.example.mlbbbot

import android.graphics.Bitmap
import android.graphics.Rect

/** Screenshot ထဲက pixel အရောင်ကြည့်ပြီး HP နဲ့ ရန်သူ ရှိမရှိ ခန့်မှန်းတယ်။ */
class Vision {
    private var maxGreen = 0

    fun reset() { maxGreen = 0 }

    private fun isGreen(c: Int): Boolean {
        val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
        return g > 140 && r < 130 && b < 130 && g - r > 50
    }

    private fun isRed(c: Int): Boolean {
        val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
        return r > 180 && g < 80 && b < 80
    }

    private fun clamp(r: Rect, bmp: Bitmap): Rect? {
        val out = Rect(r)
        return if (out.intersect(0, 0, bmp.width, bmp.height) && out.width() > 0 && out.height() > 0) out else null
    }

    /** ကိုယ့် hero ရဲ့ HP (0..1)။ bar မတွေ့ရင် null (သေနေ/loading) */
    fun heroHp(bmp: Bitmap, barArea: Rect): Float? {
        val r = clamp(barArea, bmp) ?: return null
        val w = r.width(); val h = r.height()
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, r.left, r.top, w, h)
        var best = 0
        for (y in 0 until h) {
            var n = 0
            for (x in 0 until w) if (isGreen(px[y * w + x])) n++
            if (n > best) best = n
        }
        if (best < 15) return null
        if (best > maxGreen) maxGreen = best
        return best.toFloat() / maxGreen
    }

    /** Hero ပတ်ပတ်လည်မှာ အနီရောင် HP bar (ရန်သူ/ရန်သူ minion) ရှိမရှိ */
    fun enemyNear(bmp: Bitmap, area: Rect): Boolean {
        val r = clamp(area, bmp) ?: return false
        var count = 0
        var y = r.top
        while (y < r.bottom) {
            var x = r.left
            while (x < r.right) {
                if (isRed(bmp.getPixel(x, y))) count++
                x += 2
            }
            y += 2
        }
        return count > 30
    }
}

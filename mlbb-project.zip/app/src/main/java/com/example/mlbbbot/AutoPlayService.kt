package com.example.mlbbbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * MLBB Practice (vs AI) mode အတွက်သာ။ Ranked/Classic မှာ မသုံးပါနဲ့။
 * Point index: 0 joystick, 1 attack, 2-4 skill1-3, 5 recall, 6 hero HP bar, 7 forward direction
 */
class AutoPlayService : AccessibilityService() {

    private enum class S { NORMAL, RETREAT, RECALL }

    companion object {
        const val TICK_MS = 1200L
        const val GESTURE_MS = 1100L
        const val RETREAT_HP = 0.30f
        const val RECOVERED_HP = 0.85f
        const val MISSING_LIMIT = 50          // hero bar မတွေ့ရင် ~60 စက္ကန့်အကြာ အလိုအလျောက်ရပ်
        val STEPS = listOf(
            "Joystick ရဲ့ အလယ်ကို နှိပ်ပါ",
            "Attack ခလုတ်ကို နှိပ်ပါ",
            "Skill 1 ကို နှိပ်ပါ",
            "Skill 2 ကို နှိပ်ပါ",
            "Skill 3 ကို နှိပ်ပါ",
            "Recall (B) ခလုတ်ကို နှိပ်ပါ",
            "ကိုယ့် hero ခေါင်းပေါ်က အစိမ်း HP bar ကို နှိပ်ပါ",
            "Joystick ပေါ်မှာ ရန်သူ base ဆီ သွားမယ့် ဦးတည်ချက်ကို နှိပ်ပါ"
        )
        val DEFAULTS = listOf(
            0.15f to 0.72f, 0.88f to 0.80f, 0.75f to 0.88f, 0.80f to 0.66f,
            0.92f to 0.55f, 0.52f to 0.92f, 0.50f to 0.40f, 0.22f to 0.65f
        )
    }

    private val handler = Handler(Looper.getMainLooper())
    private val vision = Vision()
    private lateinit var wm: WindowManager
    private lateinit var panel: LinearLayout
    private lateinit var startBtn: Button

    private var running = false
    private var state = S.NORMAL
    private var stateTicks = 0
    private var missing = 0
    private var pts: List<PointF> = emptyList()

    // ---------- UI ----------
    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        pts = loadPoints()
        startBtn = Button(this).apply { text = "▶"; setOnClickListener { if (running) stop(null) else start() } }
        val calBtn = Button(this).apply { text = "⚙"; setOnClickListener { startCalibration() } }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(startBtn, LinearLayout.LayoutParams(140, 140))
            addView(calBtn, LinearLayout.LayoutParams(140, 140))
        }
        wm.addView(panel, WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 150 })
        toast("⚙ နှိပ်ပြီး ခလုတ်နေရာတွေ အရင် calibrate လုပ်ပါ")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun screen(): Pair<Float, Float> {
        val dm = resources.displayMetrics
        return max(dm.widthPixels, dm.heightPixels).toFloat() to min(dm.widthPixels, dm.heightPixels).toFloat()
    }

    // ---------- Calibration ----------
    private fun startCalibration() {
        if (running) stop(null)
        val got = ArrayList<PointF>()
        val tv = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); setBackgroundColor(0xCC000000.toInt())
            setPadding(24, 16, 24, 16); gravity = Gravity.CENTER
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x22000000)
            addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        }
        fun show() { tv.text = "${got.size + 1}/${STEPS.size}: ${STEPS[got.size]}" }
        show()
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                val (w, h) = screen()
                got.add(PointF(e.rawX / w, e.rawY / h))
                if (got.size == STEPS.size) {
                    savePoints(got); pts = got.toList()
                    wm.removeView(root)
                    toast("Calibrate ပြီးပါပြီ။ ▶ နှိပ်နိုင်ပါပြီ")
                } else show()
            }
            true
        }
        wm.addView(root, WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))
    }

    private fun savePoints(l: List<PointF>) {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putString("pts", l.joinToString(";") { "${it.x},${it.y}" }).apply()
    }

    private fun loadPoints(): List<PointF> {
        val s = getSharedPreferences("cfg", MODE_PRIVATE).getString("pts", null)
        val parsed = s?.split(";")?.mapNotNull {
            val p = it.split(","); if (p.size == 2) PointF(p[0].toFloat(), p[1].toFloat()) else null
        }
        return if (parsed != null && parsed.size == STEPS.size) parsed else DEFAULTS.map { PointF(it.first, it.second) }
    }

    // ---------- Main loop ----------
    private fun start() {
        running = true; vision.reset(); state = S.NORMAL; stateTicks = 0; missing = 0
        startBtn.text = "■"
        tick()
    }

    private fun stop(msg: String?) {
        running = false
        handler.removeCallbacksAndMessages(null)
        startBtn.text = "▶"
        msg?.let { toast(it) }
    }

    private fun next() { if (running) handler.postDelayed({ tick() }, TICK_MS) }

    private fun tick() {
        if (!running) return
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hw?.recycle(); hb.close()
                if (bmp != null) { act(bmp); bmp.recycle() }
                next()
            }
            override fun onFailure(errorCode: Int) { next() }
        })
    }

    private fun act(bmp: Bitmap) {
        val (w, h) = screen()
        val hero = pts[6]
        val hx = (hero.x * w).toInt(); val hy = (hero.y * h).toInt()
        val bar = Rect(hx - (0.10f * w).toInt(), hy - (0.03f * h).toInt(), hx + (0.10f * w).toInt(), hy + (0.03f * h).toInt())
        val area = Rect(hx - (0.30f * w).toInt(), hy - (0.30f * h).toInt(), hx + (0.30f * w).toInt(), hy + (0.35f * h).toInt())

        val hp = vision.heroHp(bmp, bar)
        if (hp == null) {
            missing++
            if (missing >= MISSING_LIMIT) stop("Hero မတွေ့တော့လို့ ရပ်လိုက်ပါပြီ (match ပြီး/ကြာကြာသေနေ)")
            return
        }
        missing = 0
        val fwd = forwardDir(w, h)
        val back = PointF(-fwd.x, -fwd.y)

        when (state) {
            S.NORMAL -> {
                if (hp < RETREAT_HP) {
                    state = S.RETREAT; stateTicks = 0
                    dispatch(back, emptyList())
                    return
                }
                val enemy = vision.enemyNear(bmp, area)
                val taps = mutableListOf(1 to 100L)
                if (enemy) {
                    taps += 1 to 600L
                    for (i in 2..4) if (Random.nextFloat() < 0.5f) taps += i to Random.nextLong(150, 900)
                }
                dispatch(fwd, taps)
            }
            S.RETREAT -> {
                stateTicks++
                if (stateTicks >= 3) { state = S.RECALL; stateTicks = 0; dispatch(null, listOf(5 to 50L)) }
                else dispatch(back, emptyList())
            }
            S.RECALL -> {   // ရွေ့ရင် recall ပျက်လို့ ငြိမ်ငြိမ်နေ
                stateTicks++
                if (hp > RECOVERED_HP || stateTicks > 12) state = S.NORMAL
            }
        }
    }

    private fun forwardDir(w: Float, h: Float): PointF {
        val dx = (pts[7].x - pts[0].x) * w
        val dy = (pts[7].y - pts[0].y) * h
        val len = sqrt(dx * dx + dy * dy)
        return if (len < 1f) PointF(1f, 0f) else PointF(dx / len, dy / len)
    }

    /** dir = joystick ဆွဲမယ့် ဦးတည်ချက် (null=မဆွဲ), taps = (point index, စချိန် ms) */
    private fun dispatch(dir: PointF?, taps: List<Pair<Int, Long>>) {
        val (w, h) = screen()
        val g = GestureDescription.Builder()
        if (dir != null) {
            val c = pts[0]; val cx = c.x * w; val cy = c.y * h; val rad = 0.08f * h
            val p = Path().apply { moveTo(cx, cy); lineTo(cx + dir.x * rad, cy + dir.y * rad) }
            g.addStroke(StrokeDescription(p, 0, GESTURE_MS))
        }
        for ((i, t) in taps) {
            val p = Path().apply { moveTo(pts[i].x * w, pts[i].y * h) }
            g.addStroke(StrokeDescription(p, t, 50))
        }
        dispatchGesture(g.build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stop(null) }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::panel.isInitialized) wm.removeView(panel)
        super.onDestroy()
    }
}
